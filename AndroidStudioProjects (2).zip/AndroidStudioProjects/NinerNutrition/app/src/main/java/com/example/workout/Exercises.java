package com.example.NinerNutrition;

class Exercises {
    private String title;

    public Exercises() {
        this.title = title;
        this.wod = wod;
    }

    private String wod;

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public String getWod() {

        return wod;
    }

    public void setWod(String wod) {

        this.wod = wod;
    }



}
